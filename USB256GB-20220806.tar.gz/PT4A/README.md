Wed Jun 15 08:05:59 JST 2022

The following files must be prepared here:

5.8M    PT4A_MacIntel.tar.gz

5.8M    PT4A_MacM1.tar.gz

126M    PT4A_WSL2_Ubuntu.tar.gz

126M    PT4A_ubuntu20.tar.gz

263M    total
